<?php
session_start();
require_once '../functions.php';
$logged_in_user_data = $_SESSION['user_data'];
if($logged_in_user_data->role != 's_admin'){
    header('location: ../index.php?e_msg=Unauthorised Try');
}
require_once "../model/transactions.php";
$transactions = new transactions();
$total_tran = $transactions->totalTransactions7();
$total_received = $transactions->totalReceived();
$todays_transactions = $transactions->todays_transactions();
$total_clients = $transactions->total_clients();
$total_agents = $transactions->total_agents();
$total_receivers = $transactions->total_receivers();
$total_transactions = $transactions->totalTransactions();
$totalTransactionsThisYear = $transactions->totalTransactionsThisYear();
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>BPA | Dashboard</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="plugins/font-awesome/css/font-awesome.min.css">
    <!-- Ionicons -->
    <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="dist/css/adminlte.css">
    <!-- iCheck -->
    <link rel="stylesheet" href="plugins/iCheck/flat/blue.css">
    <link rel="stylesheet" href="dist/css/alertify.min.css">
    <link rel="stylesheet" href="dist/css/alertify.default.css">
    <link rel="stylesheet" href="plugins/jvectormap/jquery-jvectormap-1.2.2.css">
    <!-- Date Picker -->
    <link rel="stylesheet" href="plugins/datepicker/datepicker3.css">
    <link rel="stylesheet" href="dist/css/select2.css">
    <!-- Daterange picker -->
    <link rel="stylesheet" href="plugins/daterangepicker/daterangepicker-bs3.css">
    <!-- bootstrap wysihtml5 - text editor -->
    <link rel="stylesheet" href="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css">
    <!-- Google Font: Source Sans Pro -->
    <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">

    <!-- Navbar -->
    <nav class="main-header navbar navbar-expand bg-white navbar-light border-bottom">
        <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link" data-widget="pushmenu" href="#"><i class="fa fa-bars"></i></a>
            </li>

        </ul>
        <ul class="navbar-nav ml-auto">
            <!-- Messages Dropdown Menu -->
            <li class="nav-item dropdown">
                <a class="nav-link" data-toggle="dropdown" href="#">
                    <i class="fa fa-bell-o"></i>
                    <span class="badge badge-warning navbar-badge"><?php echo $todays_transactions; ?></span>
                </a>
                <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
                    <span class="dropdown-item dropdown-header"><?php echo $todays_transactions; ?> Transactions</span>
                    <div class="dropdown-divider"></div>
                    <a href="#" class="dropdown-item">
                        <i class="fa fa-exchange mr-2"></i> <b><?php echo $todays_transactions; ?></b>
                        <span class="float-right text-muted text-sm">Today's Transactions</span>
                    </a>
                    <div class="dropdown-divider"></div>
                    <a href="#" class="dropdown-item">
                        <i class="fa fa-mail-forward mr-2"></i> Received <b>$<?php echo $total_received; ?></b>
                        <span class="float-right text-muted text-sm">Last 7 days</span>
                    </a>
                    <div class="dropdown-divider"></div>
                    <a href="#" class="dropdown-item">
                        <i class="fa fa-mail-reply mr-2"></i> Sent <b>BDT <?php echo $total_tran; ?></b>
                        <span class="float-right text-muted text-sm">Last 7 days</span>
                    </a>

                </div>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-widget="control-sidebar" data-slide="true" href="#">
                    <i class="fa fa-th-large"></i>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="../controller/signout.php">
                    <i class="fa fa-sign-out"></i>
                </a>
            </li>
            <!-- Notifications Dropdown Menu -->

        </ul>
    </nav>