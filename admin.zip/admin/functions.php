<?php
require_once "../model/class.breadcrumb.inc.php";
$breadcrumb = new breadcrumb();
$filename = $breadcrumb->fileName;
