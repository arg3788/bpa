  <?php require_once "header.php"; ?>
  <?php
  require_once "sidebar.php";
  require_once "../model/transactions.php";
  $transactions = new transactions();

  $allTransactions = $transactions->getAllTransactions();
  ?>
  <link rel="stylesheet" href="plugins/datatables/dataTables.bootstrap4.min.css">
  <link rel="stylesheet" href="dist/css/animate.min.css">
  <link rel="stylesheet" href="https://cdn.datatables.net/responsive/2.2.1/css/responsive.dataTables.min.css">
  <link rel="stylesheet" href="plugins/lightbox/cobox.css">
  <style>
    .table-striped tbody tr:nth-of-type(odd) {
      background-color: rgba(0, 123, 255, 0.4) !important;
    }
    .table th, .table td {
      padding: 0.15rem;
      vertical-align: top;
      border-top: 1px solid rgba(0, 123, 255, 0.4);
    }
    .modal-header .close, .modal-header .mailbox-attachment-close {
      position: absolute;
      right: 20px;
    }
    table tr th{text-align: center !important;}
    table tr td{text-align: center;}
    .table-bordered th, .table-bordered td {
      border: none;
    }
  </style>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-sm-12">
            <div class="card-body">
              <div class="card card-primary">
                <div class="card-header">
                  <h3 class="card-title">Manage Transactions</h3>
                </div><br/>

                <table id="manage_transactions" class="table table-bordered table-striped">
                  <thead>
                  <tr>
                    <th>Action</th>
                    <th>Sender</th>
                    <th>Receiver</th>
                    <th>Agent</th>
                    <th>Amount(USD)</th>
                    <th>Rate</th>
                    <th>Sell Rate</th>
                    <th>Payable(BDT)</th>
                    <th>Paid ?</th>
                    <th>Pay Slip</th>
                    <th>Date</th>
                  </tr>
                  </thead>
                  <tbody>
                  <?php foreach ($allTransactions as $one_t){
                    $cheque_pic = '<a href="dist/img/paymentSlip/'.$one_t->payment_slip.'"><img class="fenixbox" alt="" title="Cheque" src="dist/img/paymentSlip/'.$one_t->payment_slip.'" style="width: 80px"/></a>';
                    $date = date('jS F y', strtotime(str_replace('-', '/', $one_t->date)));
                    $pay_status = $one_t->pay_status == 0 ? '<i style="color: red" class="fa fa-times"></i>' : '<i style="color: green" class="fa fa-check-square-o"></i>';
                    echo '<tr>
                <td>
                <a href="view_client.php?cid='.$one_t->ID.'"><i class="fa fa-eye"></i></a>
                <a href="update_transaction.php?t_id='.$one_t->ID.'"><i class="fa fa-edit"></i></a>
                <a target="_blank" href="print.php?t_id='.$one_t->ID.'" class="print_transaction"><i class="fa fa-print"></i></a>

                </td>
                <td><a href="view_client.php?cid='.$one_t->client_id.'">'.$one_t->client_name.'</a></td>
                <td>'.$one_t->receiver_name.'</td>
                <td>'.$one_t->agent_name.'</td>
                <td>'.$one_t->amount.'</td>
                <td>'.$one_t->buy_rate.'</td>
                <td>'.$one_t->sell_rate.'</td>
                <td>'.$one_t->amount_payable.'</td>
                <td>'.$pay_status.'</td>
                <td>'.$cheque_pic.'</td>
                <td>'.$date.'</td>

              </tr>';
                  } ?>
                  </tbody>
                  <tfoot>
                  <tr>
                    <th>Action</th>
                    <th>Sender</th>
                    <th>Receiver</th>
                    <th>Agent</th>
                    <th>Amount(USD)</th>
                    <th>Rate</th>
                    <th>Sell Rate</th>
                    <th>Payable(BDT)</th>
                    <th>Paid ?</th>
                    <th>Pay Slip</th>
                    <th>Date</th>
                  </tr>
                  </tfoot>
                </table>
              </div>
            </div>
          </div>
        </div>

      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>

  <!-- /.content-wrapper -->
  <?php require_once "footer.php"; ?>
  <script src="plugins/datatables/datatables.min.js"></script>
  <script src="plugins/datatables/dataTables.bootstrap4.min.js"></script>
  <script src="https://cdn.datatables.net/responsive/2.2.1/js/dataTables.responsive.min.js"></script>
  <script src="plugins/lightbox/cobox.js"></script>
  <script>
    $(function (){

      var manage_transactions = $('#manage_transactions').DataTable({
        "responsive": true,
        "paging": true,
        "lengthChange": true,
        "searching": true,
        "ordering": true,
        "info": true,
        "autoWidth": false
      });

      $(document).on("click",".transaction_delete .fa-trash-o",function(){
        var root = $(this).closest('tr');
        var t_id = $(this).closest('a').data('src');

        alertify.confirm("Are you sure?",function(e){
          if(e){
            $.ajax({
              method: "POST",
              url: "../controller/ajax.php",
              dataType: "text",
              data: {t_id: t_id, t_delete: 'y'},
              success: function(response){
                if(response){
                  root.addClass('animated fadeOut');
                  setTimeout(function(){
                    root.hide();
                  },1000);

                }else{
                  alertify.error("Something went wrong");
                }
              }
            });
          }else{
            alertify.error("It's Ok");
            return false;
          }
        });
      });
    });
    $(selector).slimScroll();
  </script>