  <?php require_once "header.php"; ?>
  <?php require_once "sidebar.php"; ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">

    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <!-- left column -->
          <div class="col-md-12">
            <div class="card-body">
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Add Agent</h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
              <form role="form" action="../controller/add_agent.php" method="post">
                <div class="card-body">
                  <div class="form-group">
                    <label for="exampleInputEmail1">Name:<span style="color:red;">*</span> </label>
                    <input type="text" name="name" class="form-control"  placeholder="Agent Name" required>
                  </div>
                  <div class="form-group">
                    <label for="exampleInputEmail1">Address:<span style="color:red;">*</span></label>
                    <input type="text" name="address" class="form-control"  placeholder="Agent Address" required>
                  </div>

                  <div class="form-group">
                    <label for="exampleInputEmail1">Phone/Mobile:<span style="color:red;">*</span></label>
                    <input type="number" name="mobile" class="form-control"  placeholder="Agent Phone" required>
                  </div>
                  <div class="form-group">
                    <label for="exampleInputEmail1">Agent Payment Details:<span style="color:red;">*</span></label>
                    <textarea class="payment_info" name="payment_info" style="width: 100%">
                      <div class="card-body">
                        Bank Name:<br>
                        Branch Name:<br>
                        Account Number:<br>
                        Sort Code:<br>
                        IBAN:<br>
                      </div>
                    </textarea>
                  </div>

                </div>
                <!-- /.card-body -->

                <div class="card-footer">
                  <input type="submit" name="add_agent" value="Add Agent" class="btn btn-primary">
                </div>
              </form>
            </div>
            <!-- /.card -->

          </div>
          </div>
          <!--/.col (left) -->
          <!-- right column -->

          <!--/.col (right) -->
        </div>
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <?php require_once "footer.php"; ?>
  <script src="plugins/ckeditor/ckeditor.js"></script>
  <script src="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js"></script>
  <script>
    $(document).ready(function(){
      $('textarea.payment_info').wysihtml5({
        toolbar: { fa: true }
      });
    });
  </script>