  <?php require_once "header.php"; ?>
  <?php require_once "sidebar.php"; ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">

    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <!-- left column -->
          <div class="col-md-12">
            <div class="card-body">
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Add Client</h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
              <form role="form" action="../controller/add_client.php" method="post">
                <div class="card-body">
                  <div class="form-group">
                    <label for="exampleInputEmail1">Name:<span style="color:red;">*</span> </label>
                    <input type="text" name="name" class="form-control"  placeholder="Client Name" required>
                  </div>
                  <div class="form-group">
                    <label for="exampleInputEmail1">Address:<span style="color:red;">*</span></label>
                    <input type="text" name="address" class="form-control"  placeholder="Client Address" required>
                  </div>
                  <div class="form-group">
                    <label for="exampleInputEmail1">Email:<span style="color:green;">Optional</span></label>
                    <input type="email" name="email" class="form-control"  placeholder="Client email">
                  </div>
                  <div class="form-group">
                    <label for="exampleInputEmail1">Phone/Mobile:<span style="color:red;">*</span></label>
                    <input type="number" name="mobile" class="form-control"  placeholder="Client Phone" required>
                  </div>
                  <div class="form-group">
                    <label for="exampleInputEmail1">Agent Type Client :<span style="color:red;">*</span></label>
                    <select name="type" class="form-control">
                      <option value="0">No</option>
                      <option value="1">Yes</option>
                    </select>
                  </div>
                  <div class="form-group">
                    <label for="exampleInputPassword1">Cash Amount(Optional):</label>
                    <input type="number" name="amount" class="form-control" id="exampleInputPassword1" placeholder="Amount" value="0">
                  </div>
                </div>
                <!-- /.card-body -->

                <div class="card-footer">
                  <input type="submit" name="add_client" value="Add Client" class="btn btn-primary">
                </div>
              </form>
            </div>
            <!-- /.card -->

          </div>
          </div>
          <!--/.col (left) -->
          <!-- right column -->

          <!--/.col (right) -->
        </div>
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <?php require_once "footer.php"; ?>
