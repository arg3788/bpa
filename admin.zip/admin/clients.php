  <?php require_once "header.php"; ?>
  <?php
  require_once "sidebar.php";
  require_once "../model/clients.php";
  $clients = new clients();
  $allClients = $clients->getClientAllInfo();
  ?>
  <link rel="stylesheet" href="plugins/datatables/dataTables.bootstrap4.min.css">
  <link rel="stylesheet" href="https://cdn.datatables.net/responsive/2.2.1/css/responsive.dataTables.min.css">

  <style>
    .table-striped tbody tr:nth-of-type(odd) {
      background-color: rgba(0, 123, 255, 0.4) !important;
    }
    .table th, .table td {
      padding: 0.15rem;
      vertical-align: top;
      border-top: 1px solid rgba(0, 123, 255, 0.4);
    }
  </style>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-sm-12">
            <div class="card-body">
              <div class="card card-primary">
                <div class="card-header">
                  <h3 class="card-title">Senders</h3>
                </div><br/>
                <table id="example2" class="table table-bordered table-striped">
                  <thead>
                  <tr>
                    <th>Action</th>
                    <th>Name</th>
                    <th>Address</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Balance</th>
                  </tr>
                  </thead>
                  <tbody>
                  <?php foreach ($allClients as $client){
                    if($client->type == 1){
                      $type_a = '<i class="fa fa-star-o fa-2x" style="color: red"></i>';
                    }else{
                      $type_a = '';
                    }
                    $client->amount = $client->amount > 0 ? $client->amount : 0;
                    echo '<tr>
                <td>
                  <a href="view_client.php?cid='.$client->ID.'"><i class="fa fa-eye"></i></a>
                  <a href="update_client.php?cid='.$client->ID.'"><i class="fa fa-edit"></i></a>

                </td>
                <td><a href="view_client.php?cid='.$client->ID.'">'.$client->client_name.'<sup>'.$type_a.'</sup></a></td>
                <td>'.$client->client_address.'</td>
                <td>'.$client->client_email.'</td>
                <td>'.$client->client_phone.'</td>
                <td><i class="fa fa-dollar"></i>'.$client->amount.'</td>

              </tr>';
                  } ?>
                  </tbody>
                  <tfoot>
                  <tr>
                    <th>Action</th>
                    <th>Name</th>
                    <th>Address</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Balance</th>
                  </tr>
                  </tfoot>
                </table>
              </div>
            </div>
          </div>
        </div>

      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <?php require_once "footer.php"; ?>
  <script src="plugins/datatables/datatables.min.js"></script>
  <script src="plugins/datatables/dataTables.bootstrap4.min.js"></script>
  <script src="https://cdn.datatables.net/responsive/2.2.1/js/dataTables.responsive.min.js"></script>
  <script>
    $(function () {
//      $("#example1").DataTable();
      $('#example2').DataTable({
        "responsive": true,
        "paging": true,
        "lengthChange": true,
        "searching": true,
        "ordering": true,
        "info": true,
        "autoWidth": false
      });
    });
  </script>