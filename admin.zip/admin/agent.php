  <?php require_once "header.php"; ?>
  <?php
  require_once "sidebar.php";
  require_once "../model/agent.php";
  $agents = new agent();
  $allAgents = $agents->getAgentAllInfo();

  ?>
  <link rel="stylesheet" href="plugins/datatables/dataTables.bootstrap4.min.css">
  <link rel="stylesheet" href="https://cdn.datatables.net/responsive/2.2.1/css/responsive.dataTables.min.css">

  <style>
    .table-striped tbody tr:nth-of-type(odd) {
      background-color: rgba(0, 123, 255, 0.4) !important;
    }
    .table th, .table td {
      padding: 0.15rem;
      vertical-align: top;
      border-top: 1px solid rgba(0, 123, 255, 0.4);
    }
  </style>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <section class="content">
      <div class="container-fluid">
        <div class="row">

          <div class="col-sm-12">
            <div class="card-body">
              <div class="card card-primary">
                <div class="card-header">
                  <h3 class="card-title">Agents</h3>
                </div><br/>
                <table id="example2" class="table table-bordered table-striped">
                  <thead>
                  <tr>
                    <th>Action</th>
                    <th>Name</th>
                    <th>Address</th>
                    <th>Payment Info</th>
                    <th>Phone</th>
                    <th>Balance</th>
                  </tr>
                  </thead>
                  <tbody>
                  <?php
                  $balance = 0;
                  foreach ($allAgents as $agent){
                      $balance = $agent->amount - ($agent->amount_paid + $agent->cost);
                    echo '<tr>
                <td>
                  <a href="view_agent.php?aid='.$agent->ID.'"><i class="fa fa-eye"></i></a>
                  <a href="update_agent.php?aid='.$agent->ID.'"><i class="fa fa-edit"></i></a>

                </td>
                <td><a href="view_agent.php?aid='.$agent->ID.'">'.$agent->agent_name.'</a></td>
                <td>'.$agent->agent_address.'</td>
                <td>'.$agent->payment_info.'</td>
                <td>'.$agent->agent_phone.'</td>
                <td>'.$balance.' BDT</td>
              </tr>';
                  } ?>
                  </tbody>
                  <tfoot>
                  <tr>
                    <th>Action</th>
                    <th>Name</th>
                    <th>Address</th>
                    <th>Payment Info</th>
                    <th>Phone</th>
                    <th>Balance</th>
                  </tr>
                  </tfoot>
                </table>
              </div>
            </div>
          </div>
        </div>

      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <?php require_once "footer.php"; ?>
  <script src="plugins/datatables/datatables.min.js"></script>
  <script src="plugins/datatables/dataTables.bootstrap4.min.js"></script>
  <script src="https://cdn.datatables.net/responsive/2.2.1/js/dataTables.responsive.min.js"></script>
  <script>
    $(function () {
//      $("#example1").DataTable();
      $('#example2').DataTable({
        "responsive": true,
        "paging": true,
        "lengthChange": true,
        "searching": true,
        "ordering": true,
        "info": true,
        "autoWidth": false
      });
    });
  </script>