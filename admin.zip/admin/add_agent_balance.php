  <?php require_once "header.php"; ?>
  <?php require_once "sidebar.php";
  require_once "../model/agent.php";
  $agents = new agent();
  $allAgents = $agents->getAgentAllInfo();
  ?>
  <style>
    .cheque_pic_input{display: none;}
  </style>
  <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">

    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <!-- left column -->
          <div class="col-md-12">
            <div class="card-body">
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Add Agent Balance</h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
              <form role="form" action="../controller/add_agent_balance.php" method="post" enctype="multipart/form-data">
                <div class="card-body">
                  <div class="form-group">
                    <label>Select Agent:<span style="color:red;">*</span> </label>
                    <select name="agent_id" class="form-control" required>
                      <option value="">Please Select</option>
                      <?php
                      foreach($allAgents as $agent){
                        echo '<option value="'.$agent->ID.'">'.$agent->agent_name.'</option>';
                      }
                      ?>
                    </select>
                  </div>

                  <div class="form-group">
                    <label>Amount:</label>
                    <input type="number" name="amount" class="form-control" placeholder="Amount" value="0">
                  </div>
                  <div class="form-group">
                    <label>Payment Option:</label>
                    <select name="payment_option" id="payment_option" class="form-control">
                      <option value="">Please Select</option>
                      <option value="1">Cash</option>
                      <option value="2">Cheque</option>
                    </select>
                  </div>
                  <div class="form-group cheque_pic_input">
                    <label>Cheque Picture:</label>
                    <input type="file" name="cheque_pic">
                  </div>
                  <div class="form-group">
                    <label>Date:</label>

                    <div class="input-group">
                      <div class="input-group-prepend">
                      <span class="input-group-text">
                        <i class="fa fa-calendar"></i>
                      </span>
                      </div>
                      <input name="date" type="text" class="form-control float-right" id="reservation">
                    </div>
                    <!-- /.input group -->
                  </div>
                </div>
                <!-- /.card-body -->

                <div class="card-footer">
                  <input type="submit" name="add_agent_balance" value="Submit" class="btn btn-primary">
                </div>
              </form>
            </div>
            <!-- /.card -->

          </div>
          </div>
          <!--/.col (left) -->
          <!-- right column -->

          <!--/.col (right) -->
        </div>
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <?php require_once "footer.php"; ?>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  <script>
    $(document).ready(function(){
      $('#reservation').datepicker({
        dateFormat: 'yy-mm-dd'
      });
      $('#payment_option').change(function(){
        var payment_option = $(this).val();
        if(payment_option == 2){
          $(".cheque_pic_input").show();
        }else{
          $(".cheque_pic_input").hide();
          $('input[name=cheque_pic]').val('');
        }
      });
    })
  </script>
